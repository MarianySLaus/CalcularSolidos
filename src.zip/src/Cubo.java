public class Cubo {
    public static double calcularVolume(double lado){
        double volume = 0.0;
        volume = lado*lado*lado;
        return volume;
    }
}

